package com.example.whiteeyedenderman.util;

import net.minecraft.block.Blocks;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;

public final class EerieStructures {

    private static final String[] MESSAGES = {
            "I SEE YOU",
            "GO BACK",
            "0100100101",
            "STOP DIGGING",
            "HE WATCHES",
            "3 6 9",
            "NOT ALONE",
            "BEHIND YOU"
    };

    private EerieStructures() {
    }

    public static void placeRandomStructure(ServerWorld world, BlockPos origin) {
        Random random = world.getRandom();
        int choice = random.nextInt(3);
        switch (choice) {
            case 0 -> placeHerobrinePillar(world, origin);
            case 1 -> placeCrypticSign(world, origin, random);
            default -> placeObsidianPlatform(world, origin);
        }
    }

    private static void placeHerobrinePillar(ServerWorld world, BlockPos origin) {
        BlockPos base = findSurface(world, origin);
        world.setBlockState(base, Blocks.DIRT.getDefaultState());
        world.setBlockState(base.up(), Blocks.DIRT.getDefaultState());
        world.setBlockState(base.up(2), Blocks.TORCH.getDefaultState());
    }

    private static void placeObsidianPlatform(ServerWorld world, BlockPos origin) {
        BlockPos base = findSurface(world, origin);
        for (BlockPos pos : BlockPos.iterate(base.add(-1, 0, -1), base.add(1, 0, 1))) {
            world.setBlockState(pos.toImmutable(), Blocks.OBSIDIAN.getDefaultState());
        }
        world.setBlockState(base.up(), Blocks.TORCH.getDefaultState());
    }

    private static void placeCrypticSign(ServerWorld world, BlockPos origin, Random random) {
        BlockPos base = findSurface(world, origin);
        world.setBlockState(base, Blocks.OAK_SIGN.getDefaultState());
        if (world.getBlockEntity(base) instanceof SignBlockEntity sign) {
            String message = MESSAGES[random.nextInt(MESSAGES.length)];
            sign.changeText(text -> text.withMessage(0, Text.literal(message)), true);
        }
    }

    private static BlockPos findSurface(ServerWorld world, BlockPos near) {
        return world.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, near);
    }
}