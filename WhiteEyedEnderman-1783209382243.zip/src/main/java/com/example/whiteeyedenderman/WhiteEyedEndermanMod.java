package com.example.whiteeyedenderman;

import com.example.whiteeyedenderman.entity.ModEntities;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WhiteEyedEndermanMod implements ModInitializer {
    public static final String MOD_ID = "whiteeyedenderman";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModEntities.initialize();
    }
}