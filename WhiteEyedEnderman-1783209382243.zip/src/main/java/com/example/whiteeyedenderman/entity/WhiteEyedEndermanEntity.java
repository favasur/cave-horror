package com.example.whiteeyedenderman.entity;

import com.example.whiteeyedenderman.entity.ai.CaveAggressionGoal;
import com.example.whiteeyedenderman.entity.ai.EerieStructureGoal;
import com.example.whiteeyedenderman.entity.ai.PhaseThroughBlocksGoal;
import com.example.whiteeyedenderman.entity.ai.StalkPlayerGoal;
import com.example.whiteeyedenderman.entity.ai.StructureSabotageGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LightType;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;

public class WhiteEyedEndermanEntity extends EndermanEntity {

    private static final TrackedData<Boolean> STALKER_ANGRY = DataTracker.registerData(
            WhiteEyedEndermanEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

    private int nightsStalked = 0;
    private long lastStalkDay = -1L;

    public WhiteEyedEndermanEntity(EntityType<? extends EndermanEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.MAX_HEALTH, 40.0)
                .add(EntityAttributes.MOVEMENT_SPEED, 0.3)
                .add(EntityAttributes.ATTACK_DAMAGE, 7.0)
                .add(EntityAttributes.FOLLOW_RANGE, 64.0);
    }

    public static boolean canSpawnCustom(EntityType<WhiteEyedEndermanEntity> type, ServerWorldAccess world,
            SpawnReason reason, BlockPos pos, Random random) {
        boolean underground = !world.isSkyVisible(pos);
        if (underground) {
            return random.nextFloat() < 0.15f;
        }
        boolean darkEnough = world.getLightLevel(LightType.SKY, pos) <= 4;
        boolean night = world.toServerWorld().isNight();
        return darkEnough && night && random.nextFloat() < 0.02f;
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(1, new PhaseThroughBlocksGoal(this));
        this.goalSelector.add(2, new CaveAggressionGoal(this));
        this.goalSelector.add(5, new StalkPlayerGoal(this));
        this.goalSelector.add(6, new StructureSabotageGoal(this));
        this.goalSelector.add(7, new EerieStructureGoal(this));
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(STALKER_ANGRY, false);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getTarget() == null && this.isStalkerAngry()) {
            this.setStalkerAngry(false);
        }
    }

    @Override
    protected void writeCustomData(WriteView view) {
        super.writeCustomData(view);
        view.putInt("NightsStalked", this.nightsStalked);
        view.putLong("LastStalkDay", this.lastStalkDay);
    }

    @Override
    protected void readCustomData(ReadView view) {
        super.readCustomData(view);
        this.nightsStalked = view.getInt("NightsStalked", 0);
        this.lastStalkDay = view.getLong("LastStalkDay", -1L);
    }

    public boolean isStalkerAngry() {
        return this.dataTracker.get(STALKER_ANGRY);
    }

    public void setStalkerAngry(boolean angry) {
        this.dataTracker.set(STALKER_ANGRY, angry);
    }

    public int getNightsStalked() {
        return this.nightsStalked;
    }

    public void incrementNightsStalked() {
        this.nightsStalked++;
    }

    public long getLastStalkDay() {
        return this.lastStalkDay;
    }

    public void setLastStalkDay(long day) {
        this.lastStalkDay = day;
    }
}