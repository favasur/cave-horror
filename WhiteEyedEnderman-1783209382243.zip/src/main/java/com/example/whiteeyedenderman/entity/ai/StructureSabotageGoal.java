package com.example.whiteeyedenderman.entity.ai;

import com.example.whiteeyedenderman.entity.WhiteEyedEndermanEntity;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.EnumSet;

public class StructureSabotageGoal extends Goal {

    private final WhiteEyedEndermanEntity enderman;
    private int cooldown;

    public StructureSabotageGoal(WhiteEyedEndermanEntity enderman) {
        this.enderman = enderman;
        this.setControls(EnumSet.of(Control.MOVE));
    }

    @Override
    public boolean canStart() {
        if (this.enderman.getTarget() != null || this.enderman.isStalkerAngry()) {
            return false;
        }
        if (this.cooldown > 0) {
            this.cooldown--;
            return false;
        }
        World world = this.enderman.getEntityWorld();
        if (!(world instanceof ServerWorld serverWorld)) {
            return false;
        }
        PlayerEntity nearest = world.getClosestPlayer(this.enderman, 32.0);
        if (nearest != null && nearest.canSee(this.enderman)) {
            return false;
        }
        BlockPos torch = findNearbyLightSource(serverWorld, this.enderman.getBlockPos(), 8);
        if (torch == null) {
            return false;
        }
        this.cooldown = 600;
        breakLightSource(serverWorld, torch);
        maybeBlockDoorway(serverWorld, this.enderman.getBlockPos(), 6);
        return false;
    }

    @Override
    public boolean shouldContinue() {
        return false;
    }

    private BlockPos findNearbyLightSource(ServerWorld world, BlockPos center, int radius) {
        for (BlockPos pos : BlockPos.iterate(center.add(-radius, -radius, -radius), center.add(radius, radius, radius))) {
            Block block = world.getBlockState(pos).getBlock();
            if (block == Blocks.TORCH || block == Blocks.WALL_TORCH
                    || block == Blocks.LANTERN || block == Blocks.SOUL_TORCH
                    || block == Blocks.SOUL_WALL_TORCH || block == Blocks.SOUL_LANTERN) {
                return pos.toImmutable();
            }
        }
        return null;
    }

    private void breakLightSource(ServerWorld world, BlockPos pos) {
        world.breakBlock(pos, false);
    }

    private void maybeBlockDoorway(ServerWorld world, BlockPos center, int radius) {
        if (world.getRandom().nextFloat() > 0.3f) {
            return;
        }
        for (BlockPos pos : BlockPos.iterate(center.add(-radius, -1, -radius), center.add(radius, 2, radius))) {
            if (world.getBlockState(pos).isAir()
                    && world.getBlockState(pos.down()).isSolidBlock(world, pos.down())
                    && world.getBlockState(pos.up()).isAir()
                    && world.getBlockState(pos.north()).isSolidBlock(world, pos.north())
                    && world.getBlockState(pos.south()).isSolidBlock(world, pos.south())) {
                world.setBlockState(pos, Blocks.COBBLESTONE.getDefaultState());
                break;
            }
        }
    }
}