package com.example.whiteeyedenderman.entity.ai;

import com.example.whiteeyedenderman.entity.WhiteEyedEndermanEntity;
import com.example.whiteeyedenderman.util.EerieStructures;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

import java.util.EnumSet;

public class EerieStructureGoal extends Goal {

    private final WhiteEyedEndermanEntity enderman;
    private int cooldown = 1200;

    public EerieStructureGoal(WhiteEyedEndermanEntity enderman) {
        this.enderman = enderman;
        this.setControls(EnumSet.noneOf(Control.class));
    }

    @Override
    public boolean canStart() {
        if (this.cooldown > 0) {
            this.cooldown--;
            return false;
        }
        if (this.enderman.getTarget() != null || this.enderman.isStalkerAngry()) {
            return false;
        }
        World world = this.enderman.getEntityWorld();
        if (!(world instanceof ServerWorld serverWorld)) {
            return false;
        }
        PlayerEntity nearest = world.getClosestPlayer(this.enderman, 40.0);
        if (nearest != null && nearest.canSee(this.enderman)) {
            return false;
        }
        if (serverWorld.getRandom().nextFloat() > 0.15f) {
            this.cooldown = 200;
            return false;
        }
        EerieStructures.placeRandomStructure(serverWorld, this.enderman.getBlockPos());
        this.cooldown = 6000;
        return false;
    }

    @Override
    public boolean shouldContinue() {
        return false;
    }
}