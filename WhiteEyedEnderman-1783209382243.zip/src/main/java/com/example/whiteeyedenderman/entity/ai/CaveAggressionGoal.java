package com.example.whiteeyedenderman.entity.ai;

import com.example.whiteeyedenderman.entity.WhiteEyedEndermanEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.EnumSet;

public class CaveAggressionGoal extends Goal {

    private final WhiteEyedEndermanEntity enderman;
    private PlayerEntity target;
    private int triggerCooldown;
    private int giveUpTicks;
    private int attackCooldown;

    public CaveAggressionGoal(WhiteEyedEndermanEntity enderman) {
        this.enderman = enderman;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK, Control.TARGET));
    }

    @Override
    public boolean canStart() {
        if (this.enderman.getTarget() != null) {
            return false;
        }
        if (this.triggerCooldown > 0) {
            this.triggerCooldown--;
            return false;
        }
        World world = this.enderman.getEntityWorld();
        if (!(world instanceof ServerWorld serverWorld)) {
            return false;
        }
        BlockPos pos = this.enderman.getBlockPos();
        if (world.isSkyVisible(pos)) {
            return false;
        }
        PlayerEntity player = world.getClosestPlayer(this.enderman, 20.0);
        if (player == null || player.isSpectator() || player.isCreative()) {
            return false;
        }
        boolean staring = player.canSee(this.enderman) && isPlayerLookingAt(player);
        double chance = staring ? 0.04 : 0.005;
        if (serverWorld.getRandom().nextDouble() >= chance) {
            return false;
        }
        this.target = player;
        return true;
    }

    @Override
    public void start() {
        this.enderman.setTarget(this.target);
        this.enderman.setStalkerAngry(true);
        this.giveUpTicks = 400;
        this.attackCooldown = 0;
    }

    @Override
    public boolean shouldContinue() {
        return this.target != null && this.target.isAlive() && this.giveUpTicks > 0
                && this.target.squaredDistanceTo(this.enderman) < 900.0;
    }

    @Override
    public void tick() {
        this.giveUpTicks--;
        if (this.attackCooldown > 0) {
            this.attackCooldown--;
        }
        this.enderman.getLookControl().lookAt(this.target, 30.0f, 30.0f);
        this.enderman.getNavigation().startMovingTo(this.target, 1.0);
        double distSq = this.enderman.squaredDistanceTo(this.target);
        if (distSq < 4.5 && this.attackCooldown <= 0) {
            World world = this.enderman.getEntityWorld();
            if (world instanceof ServerWorld serverWorld) {
                double damage = this.enderman.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);
                this.target.damage(serverWorld, this.enderman.getDamageSources().mobAttack(this.enderman), (float) damage);
                this.attackCooldown = 20;
            }
        }
    }

    @Override
    public void stop() {
        this.triggerCooldown = 300;
        this.enderman.setTarget(null);
        this.enderman.setStalkerAngry(false);
        this.target = null;
    }

    private boolean isPlayerLookingAt(PlayerEntity player) {
        Vec3d look = player.getRotationVec(1.0f).normalize();
        Vec3d toTarget = this.enderman.getPos().subtract(player.getPos()).normalize();
        return look.dotProduct(toTarget) > 0.97;
    }
}