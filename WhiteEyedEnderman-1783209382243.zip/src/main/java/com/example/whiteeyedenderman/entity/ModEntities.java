package com.example.whiteeyedenderman.entity;

import com.example.whiteeyedenderman.WhiteEyedEndermanMod;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnLocationTypes;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;

public class ModEntities {

    public static final RegistryKey<EntityType<?>> WHITE_EYED_ENDERMAN_KEY = RegistryKey.of(
            RegistryKeys.ENTITY_TYPE, Identifier.of(WhiteEyedEndermanMod.MOD_ID, "white_eyed_enderman"));

    public static final EntityType<WhiteEyedEndermanEntity> WHITE_EYED_ENDERMAN = Registry.register(
            Registries.ENTITY_TYPE,
            WHITE_EYED_ENDERMAN_KEY,
            EntityType.Builder.create(WhiteEyedEndermanEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6f, 2.9f)
                    .build(WHITE_EYED_ENDERMAN_KEY)
    );

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(WHITE_EYED_ENDERMAN, WhiteEyedEndermanEntity.createAttributes());

        SpawnRestriction.register(
                WHITE_EYED_ENDERMAN,
                SpawnLocationTypes.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                WhiteEyedEndermanEntity::canSpawnCustom
        );

        BiomeModifications.addSpawn(
                BiomeSelectors.foundInOverworld(),
                SpawnGroup.MONSTER,
                WHITE_EYED_ENDERMAN,
                2,
                1,
                1
        );
    }
}