package com.example.whiteeyedenderman.entity.ai;

import com.example.whiteeyedenderman.entity.WhiteEyedEndermanEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.EnumSet;

public class StalkPlayerGoal extends Goal {

    private final WhiteEyedEndermanEntity enderman;
    private PlayerEntity target;
    private int watchTicks;

    public StalkPlayerGoal(WhiteEyedEndermanEntity enderman) {
        this.enderman = enderman;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        if (this.enderman.isStalkerAngry() || this.enderman.getTarget() != null) {
            return false;
        }
        World world = this.enderman.getEntityWorld();
        if (!(world instanceof ServerWorld)) {
            return false;
        }
        if (!world.isNight()) {
            return false;
        }
        PlayerEntity nearest = world.getClosestPlayer(this.enderman, 64.0);
        if (nearest == null || nearest.isSpectator() || nearest.isCreative()) {
            return false;
        }
        long day = world.getTimeOfDay() / 24000L;
        if (day == this.enderman.getLastStalkDay()) {
            return false;
        }
        this.target = nearest;
        return true;
    }

    @Override
    public void start() {
        ServerWorld world = (ServerWorld) this.enderman.getEntityWorld();
        long day = world.getTimeOfDay() / 24000L;
        this.enderman.setLastStalkDay(day);
        this.enderman.incrementNightsStalked();
        int distance = Math.max(6, 36 - this.enderman.getNightsStalked() * 5);
        BlockPos dest = findHiddenPosition(world, this.target.getBlockPos(), distance);
        if (dest != null) {
            this.enderman.requestTeleport(dest.getX() + 0.5, dest.getY(), dest.getZ() + 0.5);
        }
        this.watchTicks = 100 + world.getRandom().nextInt(100);
    }

    @Override
    public boolean shouldContinue() {
        return this.watchTicks > 0 && this.target != null && this.target.isAlive()
                && this.enderman.getTarget() == null;
    }

    @Override
    public void tick() {
        this.watchTicks--;
        if (this.target != null) {
            this.enderman.getLookControl().lookAt(this.target, 30.0f, 30.0f);
        }
    }

    @Override
    public void stop() {
        this.target = null;
    }

    private BlockPos findHiddenPosition(ServerWorld world, BlockPos center, int distance) {
        Random random = world.getRandom();
        for (int i = 0; i < 16; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            int dx = (int) (Math.cos(angle) * distance);
            int dz = (int) (Math.sin(angle) * distance);
            BlockPos candidate = center.add(dx, 0, dz);
            BlockPos ground = world.getTopPosition(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, candidate);
            if (world.getBlockState(ground.down()).isSolidBlock(world, ground.down())
                    && world.getBlockState(ground).isAir()
                    && world.getBlockState(ground.up()).isAir()) {
                return ground;
            }
        }
        return null;
    }
}