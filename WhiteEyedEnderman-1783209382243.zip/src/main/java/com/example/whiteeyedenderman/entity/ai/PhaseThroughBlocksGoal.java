package com.example.whiteeyedenderman.entity.ai;

import com.example.whiteeyedenderman.entity.WhiteEyedEndermanEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.EnumSet;

public class PhaseThroughBlocksGoal extends Goal {

    private final WhiteEyedEndermanEntity enderman;
    private int stuckTicks;
    private int phaseCooldown;

    public PhaseThroughBlocksGoal(WhiteEyedEndermanEntity enderman) {
        this.enderman = enderman;
        this.setControls(EnumSet.of(Control.MOVE));
    }

    @Override
    public boolean canStart() {
        if (!this.enderman.isStalkerAngry()) {
            return false;
        }
        LivingEntity target = this.enderman.getTarget();
        if (target == null) {
            return false;
        }
        if (this.phaseCooldown > 0) {
            this.phaseCooldown--;
            return false;
        }
        boolean blocked = !this.enderman.canSee(target);
        boolean stuck = this.enderman.getNavigation().isIdle();
        if (blocked && stuck) {
            this.stuckTicks++;
        } else {
            this.stuckTicks = 0;
        }
        return this.stuckTicks > 20;
    }

    @Override
    public void start() {
        LivingEntity target = this.enderman.getTarget();
        World world = this.enderman.getEntityWorld();
        if (target != null && world instanceof ServerWorld) {
            Vec3d direction = target.getPos().subtract(this.enderman.getPos());
            double distance = Math.min(6.0, direction.length());
            if (distance > 0.5) {
                Vec3d step = direction.normalize().multiply(distance);
                Vec3d dest = this.enderman.getPos().add(step);
                this.enderman.requestTeleport(dest.x, dest.y, dest.z);
            }
        }
        this.stuckTicks = 0;
        this.phaseCooldown = 60;
    }

    @Override
    public boolean shouldContinue() {
        return false;
    }
}