package com.example.whiteeyedenderman.client;

import com.example.whiteeyedenderman.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.EndermanEntityRenderer;

public class WhiteEyedEndermanClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.WHITE_EYED_ENDERMAN, EndermanEntityRenderer::new);
    }
}